var config =[
	{"attr_name":"CurrentMenuId",
	"value_enum":{"1":"蔬菜","2":"豆浆"},
	"nick_name":"工作模式"
  },
	{"attr_name":"WorkState",
	"value_enum":{"0":"待机","4":"工作中"},
	"nick_name":"设备状态"
  }
]
